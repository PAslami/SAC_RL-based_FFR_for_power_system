/*
 * Freq_model.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Freq_model".
 *
 * Model version              : 1.13
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Mon Jul 31 13:13:05 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Freq_model.h"
#include "Freq_model_private.h"

/* Block signals (default storage) */
B_Freq_model_T Freq_model_B;

/* Continuous states */
X_Freq_model_T Freq_model_X;

/* Block states (default storage) */
DW_Freq_model_T Freq_model_DW;

/* External inputs (root inport signals with default storage) */
ExtU_Freq_model_T Freq_model_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_Freq_model_T Freq_model_Y;

/* Real-time model */
static RT_MODEL_Freq_model_T Freq_model_M_;
RT_MODEL_Freq_model_T *const Freq_model_M = &Freq_model_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 8;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Freq_model_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  Freq_model_output();
  Freq_model_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  Freq_model_output();
  Freq_model_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void Freq_model_output(void)
{
  uint32_T ri;
  if (rtmIsMajorTimeStep(Freq_model_M)) {
    /* set solver stop time */
    if (!(Freq_model_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&Freq_model_M->solverInfo,
                            ((Freq_model_M->Timing.clockTickH0 + 1) *
        Freq_model_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&Freq_model_M->solverInfo,
                            ((Freq_model_M->Timing.clockTick0 + 1) *
        Freq_model_M->Timing.stepSize0 + Freq_model_M->Timing.clockTickH0 *
        Freq_model_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Freq_model_M)) {
    Freq_model_M->Timing.t[0] = rtsiGetT(&Freq_model_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(Freq_model_M)) {
    /* UnitDelay: '<Root>/Unit Delay5' */
    Freq_model_B.UnitDelay5 = Freq_model_DW.UnitDelay5_DSTATE;
  }

  /* StateSpace: '<Root>/State-Space2' */
  Freq_model_B.StateSpace2[0] = 0.0;
  Freq_model_B.StateSpace2[1] = 0.0;
  for (ri = Freq_model_P.StateSpace2_C_jc[0U]; ri <
       Freq_model_P.StateSpace2_C_jc[1U]; ri++) {
    Freq_model_B.StateSpace2[Freq_model_P.StateSpace2_C_ir[ri]] +=
      Freq_model_P.StateSpace2_C_pr[ri] * Freq_model_X.StateSpace2_CSTATE[0U];
  }

  for (ri = Freq_model_P.StateSpace2_C_jc[1U]; ri <
       Freq_model_P.StateSpace2_C_jc[2U]; ri++) {
    Freq_model_B.StateSpace2[Freq_model_P.StateSpace2_C_ir[ri]] +=
      Freq_model_P.StateSpace2_C_pr[ri] * Freq_model_X.StateSpace2_CSTATE[1U];
  }

  /* End of StateSpace: '<Root>/State-Space2' */
  if (rtmIsMajorTimeStep(Freq_model_M)) {
    /* UnitDelay: '<Root>/Unit Delay4' */
    Freq_model_B.UnitDelay4[0] = Freq_model_DW.UnitDelay4_DSTATE[0];
    Freq_model_B.UnitDelay4[1] = Freq_model_DW.UnitDelay4_DSTATE[1];
    Freq_model_B.UnitDelay4[2] = Freq_model_DW.UnitDelay4_DSTATE[2];

    /* UnitDelay: '<Root>/Unit Delay3' */
    memcpy(&Freq_model_B.UnitDelay3[0], &Freq_model_DW.UnitDelay3_DSTATE[0], 9U *
           sizeof(real_T));

    /* S-Function (KF_Sfun): '<Root>/S-Function Builder1' incorporates:
     *  Constant: '<Root>/Constant10'
     *  Constant: '<Root>/Constant11'
     *  Constant: '<Root>/Constant8'
     *  Constant: '<Root>/Constant9'
     *  Outport: '<Root>/x_est'
     */
    KF_Sfun_Outputs_wrapper(&Freq_model_B.UnitDelay5, &Freq_model_B.StateSpace2
      [0], &Freq_model_B.UnitDelay4[0], &Freq_model_B.UnitDelay3[0],
      &Freq_model_P.Constant8_Value, &Freq_model_P.Constant9_Value,
      &Freq_model_P.Constant10_Value, &Freq_model_P.Constant11_Value,
      &Freq_model_Y.x_est[0], &Freq_model_B.SFunctionBuilder1_o2[0]);
  }

  /* StateSpace: '<Root>/State-Space3' */
  Freq_model_B.StateSpace3[0] = 0.0;
  Freq_model_B.StateSpace3[1] = 0.0;
  for (ri = Freq_model_P.StateSpace3_C_jc[0U]; ri <
       Freq_model_P.StateSpace3_C_jc[1U]; ri++) {
    Freq_model_B.StateSpace3[Freq_model_P.StateSpace3_C_ir[ri]] +=
      Freq_model_P.StateSpace3_C_pr[ri] * Freq_model_X.StateSpace3_CSTATE[0U];
  }

  for (ri = Freq_model_P.StateSpace3_C_jc[1U]; ri <
       Freq_model_P.StateSpace3_C_jc[2U]; ri++) {
    Freq_model_B.StateSpace3[Freq_model_P.StateSpace3_C_ir[ri]] +=
      Freq_model_P.StateSpace3_C_pr[ri] * Freq_model_X.StateSpace3_CSTATE[1U];
  }

  /* End of StateSpace: '<Root>/State-Space3' */
  if (rtmIsMajorTimeStep(Freq_model_M)) {
  }

  /* Sum: '<Root>/Add2' incorporates:
   *  Inport: '<Root>/L'
   *  Inport: '<Root>/u'
   *  TransferFcn: '<Root>/Transfer Fcn3'
   */
  Freq_model_B.Add2 = (Freq_model_P.TransferFcn3_C *
                       Freq_model_X.TransferFcn3_CSTATE + Freq_model_U.u) -
    Freq_model_U.L;

  /* Sum: '<Root>/Add6' incorporates:
   *  Constant: '<Root>/Constant'
   *  Inport: '<Root>/L'
   *  TransferFcn: '<Root>/Transfer Fcn16'
   */
  Freq_model_B.Add6 = (Freq_model_P.TransferFcn16_C *
                       Freq_model_X.TransferFcn16_CSTATE +
                       Freq_model_P.Constant_Value) - Freq_model_U.L;

  /* TransferFcn: '<Root>/Transfer Fcn15' */
  Freq_model_B.TransferFcn15 = 0.0;
  Freq_model_B.TransferFcn15 += Freq_model_P.TransferFcn15_C *
    Freq_model_X.TransferFcn15_CSTATE;

  /* TransferFcn: '<Root>/Transfer Fcn2' */
  Freq_model_B.TransferFcn2 = 0.0;
  Freq_model_B.TransferFcn2 += Freq_model_P.TransferFcn2_C *
    Freq_model_X.TransferFcn2_CSTATE;
}

/* Model update function */
void Freq_model_update(void)
{
  if (rtmIsMajorTimeStep(Freq_model_M)) {
    /* Update for UnitDelay: '<Root>/Unit Delay5' incorporates:
     *  Inport: '<Root>/u'
     */
    Freq_model_DW.UnitDelay5_DSTATE = Freq_model_U.u;

    /* Update for UnitDelay: '<Root>/Unit Delay4' incorporates:
     *  Outport: '<Root>/x_est'
     */
    Freq_model_DW.UnitDelay4_DSTATE[0] = Freq_model_Y.x_est[0];
    Freq_model_DW.UnitDelay4_DSTATE[1] = Freq_model_Y.x_est[1];
    Freq_model_DW.UnitDelay4_DSTATE[2] = Freq_model_Y.x_est[2];

    /* Update for UnitDelay: '<Root>/Unit Delay3' incorporates:
     *  S-Function (KF_Sfun): '<Root>/S-Function Builder1'
     */
    memcpy(&Freq_model_DW.UnitDelay3_DSTATE[0],
           &Freq_model_B.SFunctionBuilder1_o2[0], 9U * sizeof(real_T));
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(Freq_model_M)!=-1) &&
        !((rtmGetTFinal(Freq_model_M)-(((Freq_model_M->Timing.clockTick1+
             Freq_model_M->Timing.clockTickH1* 4294967296.0)) * 0.02)) >
          (((Freq_model_M->Timing.clockTick1+Freq_model_M->Timing.clockTickH1*
             4294967296.0)) * 0.02) * (DBL_EPSILON))) {
      rtmSetErrorStatus(Freq_model_M, "Simulation finished");
    }
  }

  if (rtmIsMajorTimeStep(Freq_model_M)) {
    rt_ertODEUpdateContinuousStates(&Freq_model_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Freq_model_M->Timing.clockTick0)) {
    ++Freq_model_M->Timing.clockTickH0;
  }

  Freq_model_M->Timing.t[0] = rtsiGetSolverStopTime(&Freq_model_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.02s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.02, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    Freq_model_M->Timing.clockTick1++;
    if (!Freq_model_M->Timing.clockTick1) {
      Freq_model_M->Timing.clockTickH1++;
    }
  }
}

/* Derivatives for root system: '<Root>' */
void Freq_model_derivatives(void)
{
  XDot_Freq_model_T *_rtXdot;
  uint32_T ri;
  _rtXdot = ((XDot_Freq_model_T *) Freq_model_M->derivs);

  /* Derivatives for StateSpace: '<Root>/State-Space2' */
  _rtXdot->StateSpace2_CSTATE[0] = 0.0;
  _rtXdot->StateSpace2_CSTATE[1] = 0.0;
  for (ri = Freq_model_P.StateSpace2_A_jc[0U]; ri <
       Freq_model_P.StateSpace2_A_jc[1U]; ri++) {
    _rtXdot->StateSpace2_CSTATE[Freq_model_P.StateSpace2_A_ir[ri]] +=
      Freq_model_P.StateSpace2_A_pr[ri] * Freq_model_X.StateSpace2_CSTATE[0U];
  }

  for (ri = Freq_model_P.StateSpace2_A_jc[1U]; ri <
       Freq_model_P.StateSpace2_A_jc[2U]; ri++) {
    _rtXdot->StateSpace2_CSTATE[Freq_model_P.StateSpace2_A_ir[ri]] +=
      Freq_model_P.StateSpace2_A_pr[ri] * Freq_model_X.StateSpace2_CSTATE[1U];
  }

  for (ri = Freq_model_P.StateSpace2_B_jc[0U]; ri <
       Freq_model_P.StateSpace2_B_jc[1U]; ri++) {
    _rtXdot->StateSpace2_CSTATE[Freq_model_P.StateSpace2_B_ir] +=
      Freq_model_P.StateSpace2_B_pr * Freq_model_B.Add2;
  }

  /* End of Derivatives for StateSpace: '<Root>/State-Space2' */

  /* Derivatives for StateSpace: '<Root>/State-Space3' */
  _rtXdot->StateSpace3_CSTATE[0] = 0.0;
  _rtXdot->StateSpace3_CSTATE[1] = 0.0;
  for (ri = Freq_model_P.StateSpace3_A_jc[0U]; ri <
       Freq_model_P.StateSpace3_A_jc[1U]; ri++) {
    _rtXdot->StateSpace3_CSTATE[Freq_model_P.StateSpace3_A_ir[ri]] +=
      Freq_model_P.StateSpace3_A_pr[ri] * Freq_model_X.StateSpace3_CSTATE[0U];
  }

  for (ri = Freq_model_P.StateSpace3_A_jc[1U]; ri <
       Freq_model_P.StateSpace3_A_jc[2U]; ri++) {
    _rtXdot->StateSpace3_CSTATE[Freq_model_P.StateSpace3_A_ir[ri]] +=
      Freq_model_P.StateSpace3_A_pr[ri] * Freq_model_X.StateSpace3_CSTATE[1U];
  }

  for (ri = Freq_model_P.StateSpace3_B_jc[0U]; ri <
       Freq_model_P.StateSpace3_B_jc[1U]; ri++) {
    _rtXdot->StateSpace3_CSTATE[Freq_model_P.StateSpace3_B_ir] +=
      Freq_model_P.StateSpace3_B_pr * Freq_model_B.Add6;
  }

  /* End of Derivatives for StateSpace: '<Root>/State-Space3' */

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn3' */
  _rtXdot->TransferFcn3_CSTATE = 0.0;
  _rtXdot->TransferFcn3_CSTATE += Freq_model_P.TransferFcn3_A *
    Freq_model_X.TransferFcn3_CSTATE;
  _rtXdot->TransferFcn3_CSTATE += Freq_model_B.TransferFcn2;

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn16' */
  _rtXdot->TransferFcn16_CSTATE = 0.0;
  _rtXdot->TransferFcn16_CSTATE += Freq_model_P.TransferFcn16_A *
    Freq_model_X.TransferFcn16_CSTATE;
  _rtXdot->TransferFcn16_CSTATE += Freq_model_B.TransferFcn15;

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn15' */
  _rtXdot->TransferFcn15_CSTATE = 0.0;
  _rtXdot->TransferFcn15_CSTATE += Freq_model_P.TransferFcn15_A *
    Freq_model_X.TransferFcn15_CSTATE;
  _rtXdot->TransferFcn15_CSTATE += Freq_model_B.StateSpace3[0];

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn2' */
  _rtXdot->TransferFcn2_CSTATE = 0.0;
  _rtXdot->TransferFcn2_CSTATE += Freq_model_P.TransferFcn2_A *
    Freq_model_X.TransferFcn2_CSTATE;
  _rtXdot->TransferFcn2_CSTATE += Freq_model_B.StateSpace2[0];
}

/* Model initialize function */
void Freq_model_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Freq_model_M, 0,
                sizeof(RT_MODEL_Freq_model_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Freq_model_M->solverInfo,
                          &Freq_model_M->Timing.simTimeStep);
    rtsiSetTPtr(&Freq_model_M->solverInfo, &rtmGetTPtr(Freq_model_M));
    rtsiSetStepSizePtr(&Freq_model_M->solverInfo,
                       &Freq_model_M->Timing.stepSize0);
    rtsiSetdXPtr(&Freq_model_M->solverInfo, &Freq_model_M->derivs);
    rtsiSetContStatesPtr(&Freq_model_M->solverInfo, (real_T **)
                         &Freq_model_M->contStates);
    rtsiSetNumContStatesPtr(&Freq_model_M->solverInfo,
      &Freq_model_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Freq_model_M->solverInfo,
      &Freq_model_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Freq_model_M->solverInfo,
      &Freq_model_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Freq_model_M->solverInfo,
      &Freq_model_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Freq_model_M->solverInfo, (&rtmGetErrorStatus
      (Freq_model_M)));
    rtsiSetRTModelPtr(&Freq_model_M->solverInfo, Freq_model_M);
  }

  rtsiSetSimTimeStep(&Freq_model_M->solverInfo, MAJOR_TIME_STEP);
  Freq_model_M->intgData.y = Freq_model_M->odeY;
  Freq_model_M->intgData.f[0] = Freq_model_M->odeF[0];
  Freq_model_M->intgData.f[1] = Freq_model_M->odeF[1];
  Freq_model_M->intgData.f[2] = Freq_model_M->odeF[2];
  Freq_model_M->contStates = ((X_Freq_model_T *) &Freq_model_X);
  rtsiSetSolverData(&Freq_model_M->solverInfo, (void *)&Freq_model_M->intgData);
  rtsiSetSolverName(&Freq_model_M->solverInfo,"ode3");
  rtmSetTPtr(Freq_model_M, &Freq_model_M->Timing.tArray[0]);
  rtmSetTFinal(Freq_model_M, 100.0);
  Freq_model_M->Timing.stepSize0 = 0.02;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    Freq_model_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Freq_model_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Freq_model_M->rtwLogInfo, (NULL));
    rtliSetLogT(Freq_model_M->rtwLogInfo, "tout");
    rtliSetLogX(Freq_model_M->rtwLogInfo, "");
    rtliSetLogXFinal(Freq_model_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Freq_model_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Freq_model_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(Freq_model_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Freq_model_M->rtwLogInfo, 1);
    rtliSetLogY(Freq_model_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Freq_model_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Freq_model_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &Freq_model_B), 0,
                sizeof(B_Freq_model_T));

  /* states (continuous) */
  {
    (void) memset((void *)&Freq_model_X, 0,
                  sizeof(X_Freq_model_T));
  }

  /* states (dwork) */
  (void) memset((void *)&Freq_model_DW, 0,
                sizeof(DW_Freq_model_T));

  /* external inputs */
  (void)memset(&Freq_model_U, 0, sizeof(ExtU_Freq_model_T));

  /* external outputs */
  (void)memset(&Freq_model_Y, 0, sizeof(ExtY_Freq_model_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Freq_model_M->rtwLogInfo, 0.0, rtmGetTFinal
    (Freq_model_M), Freq_model_M->Timing.stepSize0, (&rtmGetErrorStatus
    (Freq_model_M)));

  /* InitializeConditions for UnitDelay: '<Root>/Unit Delay5' */
  Freq_model_DW.UnitDelay5_DSTATE = Freq_model_P.UnitDelay5_InitialCondition;

  /* InitializeConditions for StateSpace: '<Root>/State-Space2' */
  Freq_model_X.StateSpace2_CSTATE[0] = Freq_model_P.StateSpace2_InitialCondition;
  Freq_model_X.StateSpace2_CSTATE[1] = Freq_model_P.StateSpace2_InitialCondition;

  /* InitializeConditions for UnitDelay: '<Root>/Unit Delay4' */
  Freq_model_DW.UnitDelay4_DSTATE[0] = Freq_model_P.UnitDelay4_InitialCondition;
  Freq_model_DW.UnitDelay4_DSTATE[1] = Freq_model_P.UnitDelay4_InitialCondition;
  Freq_model_DW.UnitDelay4_DSTATE[2] = Freq_model_P.UnitDelay4_InitialCondition;

  /* InitializeConditions for UnitDelay: '<Root>/Unit Delay3' */
  memcpy(&Freq_model_DW.UnitDelay3_DSTATE[0],
         &Freq_model_P.UnitDelay3_InitialCondition[0], 9U * sizeof(real_T));

  /* InitializeConditions for StateSpace: '<Root>/State-Space3' */
  Freq_model_X.StateSpace3_CSTATE[0] = Freq_model_P.StateSpace3_InitialCondition;
  Freq_model_X.StateSpace3_CSTATE[1] = Freq_model_P.StateSpace3_InitialCondition;

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn3' */
  Freq_model_X.TransferFcn3_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn16' */
  Freq_model_X.TransferFcn16_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn15' */
  Freq_model_X.TransferFcn15_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn2' */
  Freq_model_X.TransferFcn2_CSTATE = 0.0;
}

/* Model terminate function */
void Freq_model_terminate(void)
{
  /* (no terminate code required) */
}
