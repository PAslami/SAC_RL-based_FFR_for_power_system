/*
 * Freq_model_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Freq_model".
 *
 * Model version              : 1.13
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Mon Jul 31 13:13:05 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Freq_model.h"
#include "Freq_model_private.h"

/* Block parameters (default storage) */
P_Freq_model_T Freq_model_P = {
  /* Expression: 0
   * Referenced by: '<Root>/Unit Delay5'
   */
  0.0,

  /* Computed Parameter: StateSpace2_A_pr
   * Referenced by: '<Root>/State-Space2'
   */
  { -25.018749999999997, 1.0, -5.00375 },

  /* Computed Parameter: StateSpace2_B_pr
   * Referenced by: '<Root>/State-Space2'
   */
  1.25,

  /* Computed Parameter: StateSpace2_C_pr
   * Referenced by: '<Root>/State-Space2'
   */
  { 1.0, 1.0 },

  /* Expression: 0
   * Referenced by: '<Root>/State-Space2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Unit Delay4'
   */
  0.0,

  /* Expression: 1*diag([1, 1, 1])
   * Referenced by: '<Root>/Unit Delay3'
   */
  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  /* Expression: 1e-12
   * Referenced by: '<Root>/Constant8'
   */
  1.0E-12,

  /* Expression: 1e-12
   * Referenced by: '<Root>/Constant9'
   */
  1.0E-12,

  /* Expression: 4e-4
   * Referenced by: '<Root>/Constant10'
   */
  0.0004,

  /* Expression: 1e-8
   * Referenced by: '<Root>/Constant11'
   */
  1.0E-8,

  /* Computed Parameter: StateSpace3_A_pr
   * Referenced by: '<Root>/State-Space3'
   */
  { -25.018749999999997, 1.0, -5.00375 },

  /* Computed Parameter: StateSpace3_B_pr
   * Referenced by: '<Root>/State-Space3'
   */
  1.25,

  /* Computed Parameter: StateSpace3_C_pr
   * Referenced by: '<Root>/State-Space3'
   */
  { 1.0, 1.0 },

  /* Expression: 0
   * Referenced by: '<Root>/State-Space3'
   */
  0.0,

  /* Computed Parameter: TransferFcn3_A
   * Referenced by: '<Root>/Transfer Fcn3'
   */
  -5.0,

  /* Computed Parameter: TransferFcn3_C
   * Referenced by: '<Root>/Transfer Fcn3'
   */
  5.0,

  /* Expression: 0.0
   * Referenced by: '<Root>/Constant'
   */
  0.0,

  /* Computed Parameter: TransferFcn16_A
   * Referenced by: '<Root>/Transfer Fcn16'
   */
  -5.0,

  /* Computed Parameter: TransferFcn16_C
   * Referenced by: '<Root>/Transfer Fcn16'
   */
  5.0,

  /* Computed Parameter: TransferFcn15_A
   * Referenced by: '<Root>/Transfer Fcn15'
   */
  -0.0,

  /* Computed Parameter: TransferFcn15_C
   * Referenced by: '<Root>/Transfer Fcn15'
   */
  -1.8,

  /* Computed Parameter: TransferFcn2_A
   * Referenced by: '<Root>/Transfer Fcn2'
   */
  -0.0,

  /* Computed Parameter: TransferFcn2_C
   * Referenced by: '<Root>/Transfer Fcn2'
   */
  -1.8,

  /* Computed Parameter: StateSpace2_A_ir
   * Referenced by: '<Root>/State-Space2'
   */
  { 1U, 0U, 1U },

  /* Computed Parameter: StateSpace2_A_jc
   * Referenced by: '<Root>/State-Space2'
   */
  { 0U, 1U, 3U },

  /* Computed Parameter: StateSpace2_B_ir
   * Referenced by: '<Root>/State-Space2'
   */
  1U,

  /* Computed Parameter: StateSpace2_B_jc
   * Referenced by: '<Root>/State-Space2'
   */
  { 0U, 1U },

  /* Computed Parameter: StateSpace2_C_ir
   * Referenced by: '<Root>/State-Space2'
   */
  { 0U, 1U },

  /* Computed Parameter: StateSpace2_C_jc
   * Referenced by: '<Root>/State-Space2'
   */
  { 0U, 1U, 2U },

  /* Computed Parameter: StateSpace3_A_ir
   * Referenced by: '<Root>/State-Space3'
   */
  { 1U, 0U, 1U },

  /* Computed Parameter: StateSpace3_A_jc
   * Referenced by: '<Root>/State-Space3'
   */
  { 0U, 1U, 3U },

  /* Computed Parameter: StateSpace3_B_ir
   * Referenced by: '<Root>/State-Space3'
   */
  1U,

  /* Computed Parameter: StateSpace3_B_jc
   * Referenced by: '<Root>/State-Space3'
   */
  { 0U, 1U },

  /* Computed Parameter: StateSpace3_C_ir
   * Referenced by: '<Root>/State-Space3'
   */
  { 0U, 1U },

  /* Computed Parameter: StateSpace3_C_jc
   * Referenced by: '<Root>/State-Space3'
   */
  { 0U, 1U, 2U }
};
